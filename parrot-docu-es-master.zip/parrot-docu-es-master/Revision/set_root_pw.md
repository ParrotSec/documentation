sudo passwd

Ingrese ese comando y allí asigne la nueva clave que desee.


Ahora verifique que todo está ok

su

ingresa la clave que definió en el paso anterior y <i>voilà!</i>, usted ya estaría como usuario root.

