
¿QUÉ SON LOS HACKERS?

Desde que se usó por primera vez la palabra hacker ésta ha sido mal utilizada, mal interpretada y encasillada en un contexto errado. La definición más apropiada para la palabra en cuestión designaría el apelativo a alguien con talento, conocimiento, inteligencia e ingenuidad, especialmente relacionados con las operaciones de computadora, redes, seguridad, etc. En el mejor de los casos son incentivadores, probadores y aprobadores de las mejores y más nuevas tecnologías; en el peor de los casos pueden ser traviesos, perversos o delincuentes curiosos, en esta última definición encaja bien las palabras Pirata Informático.


Tomando en cuenta los términos “el mejor de los casos”  y “el peor de los casos”, existe una clasificación menos ambigua: Lammer, Newbie, Script Kiddie, Green, White, Gray y Black.

¿DE DÓNDE PROVIENE EL NOMBRE?

 Haciendo una investigación a fondo, se puede ver que el primer hacker no fue hombre, sino una mujer, y su nombre era Grace Murray Hopper. Ella fue la persona que creó el término y relacionó la palabra bug con vulnerabilidad, y se merece el título de la primera Hacker.
Cuando se habla de los primeros hackers, todos coinciden que la gente del Massachusetts Institute of Technology (MIT) fueron los precursores de acuñar la cultura hacker en 1959. Era un grupo de personas que se encargaban de solucionar problemas técnicos. Por tales motivos, podemos decir que Grace fue la primer hacker, pero no la creadora de la terminología, esa etiqueta se la pusieron a los chicos del MIT, casi 20 años después. 
Tal vez nos estemos preguntando de dónde salió la palabra hacker, y podemos decir que es una palabra prácticamente intraducible que se ha revestido, a lo largo de los años. Pero parece ser que este acrónimo se vincula muy especialmente a los llamados Hacks o, dicho de otra manera, así se llaman los golpes secos que efectuaban los técnicos de telefonía cuando intentaban reparar alguno de sus aparatos. Estos golpes secos recibían el nombre de "hachazos" o en el Argot Inglés "Hacks" y es más que probable que quienes lo hacían se denominaban Hackers. De cualquier forma, nunca sabremos con certeza el origen de esta palabra.

Del mismo modo en que Grace creó el concepto de bug o vulnerabilidad en una máquina, sin saber que en un futuro su descubrimiento tendría tanta repercusión y que existirían métodos para lograr sacar provecho de ese error, los chicos del MIT tampoco se imaginaron que sus metodologías para resolución de problemas o su manera de pensar servirían de ejemplo o serían puntos clave a la hora de hablar de los hackers.


¿A QUÉ SE DEDICAN EXACTAMENTE?

En una encuesta realizada a personas con conocimientos en el ámbito de la informática, casi en su totalidad las respuestas fueron: 
*	Se dedica al desarrollo y posee grandes conocimientos.
*	Experto en testing de vulnerabilidades y buscador de mejoras para las mismas.

¿QUÉ INFLUENCIA Y PAPEL JUEGAN EN EL MUNDO DE LA TECNOLOGÍA?

Los hackers actualmente juegan un papel muy importante en el mundo tecnológico ya que son los que se encargan de desarrollar, testear, verificar errores y otras muchas actividades que hacen que nosotros estemos más cómodos con la tecnología, ellos hacen la tecnología más intuitiva para su uso.
