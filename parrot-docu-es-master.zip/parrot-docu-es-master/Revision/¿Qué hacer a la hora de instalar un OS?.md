¿Qué hacer a la hora de instalar un OS?

Escoger versión de ParrotSec que se va a instalar dependiendo de los recursos de su ordenador descargue la versión más actualizada de ParrotSec y verificar el peso de la ISO dependiendo los recursos de su ordenador

ISO
*lite 1.5GB VERSION 3.8
*full 3.6 GB VERSION 3.8

1)Tener la documentación y soporte a la mano. Si usted es un usuario nuevo es recomendable documentarse y formar parte de
las comunidades y foros de ParrotSec 
 
<p>Grupo de telegram<p>
- https://t.me/ParrotSpanishGroup<p>
Foro en español<p>
- https://www.parrotsec-es.org


Recomendaciones al pie:

- Debe tener en cuenta tener a mano la información del Hardware.
- En GNU/Linux hay varios reportes de problemas con controladores privativos para dispositivos cómo modems integrados en board y otros periféricos menos comunes, como Mouses inalámbricos, etc. 
-También recomendamos tener una copia de los instaladores y tomar nota de todo lo que se hace y se escoge en la instalación, ya que para pedir ayuda es recomendable tener información de cualquier problema que se presente durante la instalación.
- Conocer las aplicaciones útiles
- Particionar el disco duro es opcional.
Si quiere una guía de cómo hacerlo con ParrotSec, recomendamos leer el link https://docs.parrotsec-es.org/doku.php?id=parrot_security_os_dualboot


