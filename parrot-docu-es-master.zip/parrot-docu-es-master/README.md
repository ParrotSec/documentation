<h1>Documentación oficial Parrot Security OS (español)</h1>

Bienvenidos a la documentación oficial en español de Parrot Security OS, proyecto que ha sido posible primeramente gracias al aporte de miembros de la comunidad de habla hispana de la distro del lorito.
Además de traducir el contenido publicado en https://docs.parrotsec.org/doku.php, nos preocupamos de crear nuevos contenidos, los cuales primero han sido publicados en https://community.parrotsec.org/ (foro global) y en https://community.parrotsec.org/viewforum.php?id=25 (foro de habla hispana) y que pronto serán editados para sumarlos esta documentación.

<hr>

El <b>equipo directivo</b> de Parrot Security OS en español se compone de las siguientes personas:

- <b>Lorenzo "palinuro" Faletra</b> (Director y Desarrollador Parrot Security OS)<p>
- <b>José Gatica</b> (Director de proyecto ParrotSec-ES)

- Josu Elgezabal (Director de Documentación)
- Romell Marín (Director de Documentación)
- Claudio Marcial (Director equipo web)
- Alejandro Pineda (Diseño ParrotSec-ES)
- Raúl Alderete (Material Audiovisual)
<br>
<hr>

Si quieres unirte a nosotros y colaborar con este y otros proyectos, te invitamos a unirte a nuestro grupo en Telegram a través del siguiente link https://t.me/ParrotSpanishGroup

También puedes encontrarnos en nuestra fanpage de Facebook: https://www.facebook.com/parrot.es/

Nuestra web: https://www.parrotsec-es.org/

La web de ParrotSec en inglés: https://www.parrotsec.org/

Además, si encuentras algún detalle por mejorar o corregir, puedes escribir por correo a josegatica@parrotsec.org.

<h2>¿Por qué PARROT (Loro)?</h2>

"No concebimos que un pirata que zurca los siete mares, peleando batallas y haciendo juerga con sus filibusteros, no tenga un loro en su hombro"

